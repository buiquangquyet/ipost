<?php
return array(
	'crypto_key' => 'hZkPPcW9sFe0-Ds9uQK_USRU',
	'crypto_iv' => 'J6sT0Q7ssA5U1HsM1s8-EJQ4',
	'crypto_hmac' => 'B0IqP0FDEekcdp4lV4Id8QAc',
);
