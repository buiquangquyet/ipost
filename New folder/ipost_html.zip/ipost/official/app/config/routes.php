<?php
return array(
    '_root_'  => 'root/index',       // The default route
    '_404_'   => 'exception/404',    // The main 404 route

    //--------------------------------------
    // Support/*
    //--------------------------------------
    'help'         => 'support/help/index',

);